"""Edge / Fog / Cloud simulator: command-line menu.

Usage:
    python main.py                 interactive menu
    python main.py --demo          non-interactive demo (placement + QoS + security)
    python main.py --experiments   run all four experiments, write results/ and charts
"""
import argparse
import copy
import os
import sys
import textwrap

import pandas as pd

from simulator import (POLICIES, AccessDenied, AuthError, Simulator, default_nodes,
                       generate_workload, load_workload_csv, login, save_workload_csv)

RESULTS_DIR = "results"
SHOW_COLS = ["task_id", "tenant_id", "sensitivity", "cpu", "mem", "node", "placement",
             "outcome", "total_latency_ms", "target_ms", "qos_met"]


def fmt(df):
    return df.to_string(index=False, na_rep="-")


def show_nodes(sim):
    print(fmt(pd.DataFrame(sim.snapshot())))


def show_decisions(sim):
    if not sim.decisions:
        print("No tasks placed yet. Use option 3 first.")
        return
    print(fmt(pd.DataFrame([d.as_dict() for d in sim.decisions])[SHOW_COLS]))
    print()
    print(fmt(pd.DataFrame([sim.summary()]).T.reset_index().rename(
        columns={"index": "metric", 0: "value"})))


def show_vms(sim):
    recs = sim.vms.records()
    print(fmt(pd.DataFrame(recs)) if recs else "No VMs yet.")


def run_demo():
    """Short scripted demo: placement decisions, QoS and a denied cross-tenant read."""
    tasks = generate_workload(12)
    sim = Simulator(policy="capacity_aware")
    print("== Nodes before placement ==")
    show_nodes(sim)
    res = sim.run_batch(copy.deepcopy(tasks), release=False)
    print("\n== Placement decisions (capacity-aware) ==")
    show_decisions(sim)
    print("\n== Node utilization at peak ==")
    print(fmt(pd.DataFrame(res.nodes)))
    print("\n== Simulated VM records ==")
    show_vms(sim)
    vm = next(iter(sim.vms.vms))
    sim.vms.stop(vm)
    print(f"\nStopped {vm}; its CPU/RAM were released on the host node.")
    print("\n== Security demo ==")
    alice = login("alice", "demo-alice")
    t2 = next(t for t in tasks if t.tenant_id == "T2")
    try:
        sim.store.get(alice, t2.task_id)
    except AccessDenied as e:
        print("DENIED:", e)
    print(f"alice sees {len(sim.store.list_for(alice))} tasks (tenant T1 only).")


def run_experiments(show=True):
    from simulator.experiments import run_all
    from simulator.charts import make_all
    exps = run_all(RESULTS_DIR)
    make_all(exps, RESULTS_DIR)
    if show:
        for e in exps:
            print("=" * 78)
            print(f"{e['id']}: {e['title']}")
            for label, key in (("SETUP", "setup"), ("EXPECTED", "expected"), ("ACTUAL", "actual")):
                print(textwrap.fill(e[key], width=118, initial_indent=f"{label:<9}: ",
                                    subsequent_indent=" " * 11))
            print("EXPECTATION MET:", "YES" if e["expectation_met"] else "NO")
        print("=" * 78)
        print(f"Tables, JSON and charts written to ./{RESULTS_DIR}/")
    return exps


MENU = """
 1) Show nodes                      6) Create a VM manually
 2) Choose placement policy         7) Stop a VM
 3) Generate / load workload & run  8) Log in (demo user)
 4) Show placement decisions + QoS  9) Try to read a task as the logged-in user
 5) Show VM records                10) Run all experiments (writes results/ + charts)
11) Save current results (CSV)      0) Exit
"""


def interactive():
    policy, tasks, sim, session = "capacity_aware", None, Simulator(), None
    print("Edge/Fog/Cloud simulator. Demo logins: alice/demo-alice, bob/demo-bob, "
          "carol/demo-carol, ops/demo-ops")
    while True:
        print(MENU, f"[policy: {policy} | user: {session.username if session else 'not logged in'}]")
        try:
            choice = input("Select option: ").strip()
        except EOFError:
            break
        try:
            if choice == "0":
                break
            elif choice == "1":
                show_nodes(sim)
            elif choice == "2":
                print("Policies:", ", ".join(POLICIES))
                p = input("Policy name: ").strip()
                if p in POLICIES:
                    policy = p
                    print("Policy set to", policy)
                else:
                    print("Unknown policy.")
            elif choice == "3":
                path = input("CSV path (blank = generate the reproducible 12-task sample): ").strip()
                tasks = load_workload_csv(path) if path else generate_workload(12)
                sim = Simulator(policy=policy)
                sim.run_batch(copy.deepcopy(tasks), release=False)
                print(f"Ran {len(tasks)} tasks with {policy}.")
                show_decisions(sim)
            elif choice == "4":
                show_decisions(sim)
            elif choice == "5":
                show_vms(sim)
            elif choice == "6":
                host = input("Host node (edge-1/fog-1/cloud-1): ").strip()
                vm = sim.vms.create(host, float(input("vCPU: ")), float(input("RAM GB: ")))
                print("Created", vm)
            elif choice == "7":
                print("Stopped", sim.vms.stop(input("VM id (e.g. vm-001): ").strip()))
            elif choice == "8":
                session = login(input("Username: ").strip(), input("Token: ").strip())
                print(f"Logged in as {session.username} (tenant {session.tenant}, role {session.role})")
            elif choice == "9":
                if not session:
                    print("Log in first (option 8).")
                else:
                    rec = sim.store.get(session, input("Task id (e.g. task-001): ").strip())
                    print("ALLOWED:", rec)
            elif choice == "10":
                run_experiments()
            elif choice == "11":
                os.makedirs(RESULTS_DIR, exist_ok=True)
                if sim.decisions:
                    out = os.path.join(RESULTS_DIR, "current_run_decisions.csv")
                    pd.DataFrame([d.as_dict() for d in sim.decisions]).to_csv(out, index=False)
                    print("Saved", out)
                else:
                    print("Nothing to save yet.")
            else:
                print("Unknown option.")
        except (AuthError, AccessDenied) as e:
            print("SECURITY:", e)
        except (ValueError, KeyError, FileNotFoundError) as e:
            print("ERROR:", e)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--experiments", action="store_true")
    a = ap.parse_args()
    if a.demo:
        run_demo()
    elif a.experiments:
        run_experiments()
    else:
        interactive()
