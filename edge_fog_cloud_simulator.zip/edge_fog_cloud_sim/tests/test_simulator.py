"""Unit tests (standard library unittest; no extra dependencies).

Run from the project root:  python -m unittest discover -s tests -t . -v
"""
import copy
import unittest

from simulator import (AccessDenied, AuthError, Node, Simulator, Task, TaskStore,
                       default_nodes, generate_workload, login)
from simulator.policies import capacity_aware, lowest_latency_first


def task(tid="t1", tenant="T1", cpu=1, mem=1, sens="high", work=40):
    return Task(tid, tenant, cpu, mem, sens, work, payload="synthetic")


class NodeTests(unittest.TestCase):
    def test_utilization_is_max_of_cpu_and_memory(self):
        n = Node("n", "edge", 4, 8, 5, cpu_used=1, mem_used=6)
        self.assertAlmostEqual(n.utilization, 0.75)

    def test_allocate_and_release(self):
        n = Node("n", "edge", 4, 8, 5)
        n.allocate(2, 3)
        self.assertEqual((n.cpu_used, n.mem_used), (2, 3))
        n.release(2, 3)
        self.assertEqual((n.cpu_used, n.mem_used), (0, 0))

    def test_allocate_too_much_raises(self):
        with self.assertRaises(ValueError):
            Node("n", "edge", 4, 8, 5).allocate(5, 1)

    def test_invalid_sensitivity_rejected(self):
        with self.assertRaises(ValueError):
            Task("x", "T1", 1, 1, "urgent", 10)


class PolicyTests(unittest.TestCase):
    def test_lowest_latency_picks_edge_when_free(self):
        node, _, _ = lowest_latency_first(task(), default_nodes())
        self.assertEqual(node.tier, "edge")

    def test_capacity_aware_high_goes_to_edge_then_fog(self):
        nodes = default_nodes()
        node, placement, _ = capacity_aware(task(cpu=1, mem=1), nodes)
        self.assertEqual((node.tier, placement), ("edge", "preferred"))
        nodes[0].cpu_used = nodes[0].cpu_total  # Edge full
        node, placement, _ = capacity_aware(task(cpu=1, mem=1), nodes)
        self.assertEqual((node.tier, placement), ("fog", "preferred"))

    def test_capacity_aware_low_prefers_cloud(self):
        node, _, _ = capacity_aware(task(sens="low", cpu=4, mem=8), default_nodes())
        self.assertEqual(node.tier, "cloud")

    def test_high_task_falls_back_to_cloud_when_edge_and_fog_full(self):
        nodes = default_nodes()
        for n in nodes[:2]:
            n.cpu_used = n.cpu_total
        node, placement, _ = capacity_aware(task(), nodes)
        self.assertEqual((node.tier, placement), ("cloud", "fallback"))

    def test_utilization_cap_is_respected(self):
        # Edge: 1 of 4 vCPU used; a 2-vCPU task would push it to 75%, a second to 125%
        nodes = default_nodes()
        first, _, _ = capacity_aware(task(cpu=2, mem=1), nodes)
        first.allocate(2, 1)
        second, _, _ = capacity_aware(task(cpu=2, mem=1), nodes)
        self.assertNotEqual(second.tier, "edge")

    def test_oversized_task_is_rejected(self):
        node, placement, reason = capacity_aware(task(cpu=500, mem=1), default_nodes())
        self.assertIsNone(node)
        self.assertEqual(placement, "none")
        self.assertIn("rejected", reason)


class VMTests(unittest.TestCase):
    def test_create_reserves_and_stop_releases(self):
        sim = Simulator()
        before = sim.nodes["fog-1"].cpu_used
        vm = sim.vms.create("fog-1", 2, 4)
        self.assertEqual(vm.status, "running")
        self.assertEqual(sim.nodes["fog-1"].cpu_used, before + 2)
        sim.vms.stop(vm.vm_id)
        self.assertEqual(vm.status, "stopped")
        self.assertEqual(sim.nodes["fog-1"].cpu_used, before)

    def test_stop_twice_and_unknown_vm_fail(self):
        sim = Simulator()
        vm = sim.vms.create("edge-1", 1, 1)
        sim.vms.stop(vm.vm_id)
        with self.assertRaises(ValueError):
            sim.vms.stop(vm.vm_id)
        with self.assertRaises(KeyError):
            sim.vms.stop("vm-999")

    def test_vm_record_fields(self):
        vm = Simulator().vms.create("cloud-1", 2, 4, task_id="t9")
        self.assertEqual((vm.vm_id, vm.host, vm.cpu, vm.ram, vm.task_id),
                         ("vm-001", "cloud-1", 2, 4, "t9"))


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.store = TaskStore()
        self.store.add(task("a1", "T1"))
        self.store.add(task("b1", "T2"))

    def test_login_good_and_bad(self):
        self.assertEqual(login("alice", "demo-alice").tenant, "T1")
        with self.assertRaises(AuthError):
            login("alice", "nope")
        with self.assertRaises(AuthError):
            login("mallory", "demo-alice")

    def test_tenant_cannot_read_other_tenants_task(self):
        alice = login("alice", "demo-alice")
        self.assertEqual(self.store.get(alice, "a1")["tenant_id"], "T1")
        with self.assertRaises(AccessDenied):
            self.store.get(alice, "b1")
        self.assertEqual(self.store.audit_log[-1]["result"], "DENIED")

    def test_listing_is_tenant_scoped(self):
        rows = self.store.list_for(login("bob", "demo-bob"))
        self.assertEqual([r["task_id"] for r in rows], ["b1"])

    def test_admin_can_read_any_tenant(self):
        self.assertEqual(self.store.get(login("ops", "demo-ops"), "b1")["task_id"], "b1")


class WorkloadAndEngineTests(unittest.TestCase):
    def test_workload_has_at_least_10_valid_tasks_and_is_reproducible(self):
        a, b = generate_workload(12, seed=3), generate_workload(12, seed=3)
        self.assertGreaterEqual(len(a), 10)
        self.assertEqual(a, b)
        self.assertTrue(all(t.cpu > 0 and t.mem > 0 for t in a))

    def test_counts_add_up_and_vms_released(self):
        sim = Simulator(policy="capacity_aware")
        res = sim.run_batch(copy.deepcopy(generate_workload(12)))
        s = res.summary
        self.assertEqual(s["total_tasks"], s["succeeded"] + s["failed"])
        self.assertEqual(s["succeeded"], s["qos_met"] + s["qos_violated"])
        self.assertTrue(all(v.status == "stopped" for v in sim.vms.vms.values()))
        self.assertEqual(sim.nodes["edge-1"].cpu_used, 1)  # back to background load

    def test_latency_is_network_plus_processing(self):
        sim = Simulator()
        sim.run_batch([task()], release=False)
        d = sim.decisions[0]
        self.assertAlmostEqual(d.total_latency_ms, d.net_latency_ms + d.processing_ms, places=1)

    def test_unknown_policy_rejected(self):
        with self.assertRaises(ValueError):
            Simulator(policy="random")

    def test_overload_rejects_or_reassigns(self):
        sim = Simulator(policy="capacity_aware")
        tasks = [task(f"t{i}", cpu=2, mem=3) for i in range(10)] + [task("huge", cpu=500)]
        res = sim.run_batch(tasks)
        by_id = {d.task_id: d for d in res.decisions}
        self.assertEqual(by_id["huge"].outcome, "FAILED")
        self.assertTrue(any(d.placement == "fallback" for d in res.decisions))


if __name__ == "__main__":
    unittest.main()
