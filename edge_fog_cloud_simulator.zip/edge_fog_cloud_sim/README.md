# Edge / Fog / Cloud Task-Placement Simulator

A locally runnable Python simulator that accepts computing tasks, selects an **Edge**, **Fog** or
**Cloud** node, simulates resource use, and reports performance (QoS) and security results.
No real cloud account, virtual machines or hypervisor are needed.

## 1. Setup

Requires Python 3.9 or newer.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt    # pandas, matplotlib
```

## 2. Run

| Command | What it does |
|---|---|
| `python main.py` | Interactive command-line menu (nodes, policy, workload, VMs, login, experiments) |
| `python main.py --demo` | Scripted demo: placement decisions, QoS, VM records, denied cross-tenant read |
| `python main.py --experiments` | Runs all four experiments; writes tables, JSON and charts to `results/` |
| `python -m unittest discover -s tests -t . -v` | Runs the 22 unit tests |
| `python make_evidence.py` | Re-captures console output into `evidence/` (text logs + PNG renderings) |

Demo logins (placeholder tokens, **not** real passwords): `alice/demo-alice` (tenant T1),
`bob/demo-bob` (T2), `carol/demo-carol` (T3), `ops/demo-ops` (admin).

### Suggested live-demo script
1. `python main.py`, option **1** (show the three nodes), option **3** (blank path: run the 12-task sample).
2. Option **4**: explain each placement decision, simulated latency and QoS met/violated.
3. Option **5** then **7** (`vm-001`) then **5**: show a VM being stopped and its resources released.
4. Option **8** (log in as `alice`) then option **9** with `task-001` (owned by T2): access denied.
   Then `task-002` (owned by T1): allowed.
5. Option **2** (`lowest_latency_first`) then **3** again: compare QoS with the first run.
6. Option **10**: run all experiments and open `results/chart1_policy_comparison.png`.

## 3. Project structure

```
main.py                    CLI menu, --demo, --experiments
make_evidence.py           captures console output into evidence/
requirements.txt           pandas, matplotlib
simulator/
  models.py                Node, Task, VM, Decision dataclasses
  policies.py              lowest_latency_first, capacity_aware (rules R1-R5)
  engine.py                Simulator, QoS model, default Edge/Fog/Cloud nodes
  vm_manager.py            simulated VM records: create / stop
  security.py              demo login, roles, tenant-isolated TaskStore, audit log
  workload.py              seeded workload generator, CSV load/save
  experiments.py           the four required experiments
  charts.py, diagram.py    matplotlib charts and architecture diagram
tests/test_simulator.py    22 unit tests
docs/                      architecture.png, Project_Report.docx, Presentation.pptx
results/                   CSV/JSON tables and chart PNGs
evidence/                  console logs and screenshots-style renderings
```

## 4. How it works

**Nodes** (default): Edge 4 vCPU / 8 GB / 5 ms, Fog 16 vCPU / 32 GB / 25 ms,
Cloud 64 vCPU / 256 GB / 80 ms, each with some background load. Utilization = the larger of
CPU% and memory%.

**Tasks**: CPU, memory, latency sensitivity (low / medium / high), base processing time, tenant ID.
Generate with a seed (`generate_workload(12, seed=9)`) or load from CSV (`results/workload_seed9.csv`
shows the format).

**Placement policies**
- `lowest_latency_first`: always try the lowest-latency node that physically fits.
- `capacity_aware` (the rule-based algorithm explained in the report):
  - R1: a node is eligible only if the task fits and utilization stays <= 85%.
  - R2: latency budget by sensitivity: high <= 30 ms, medium <= 100 ms, low = any.
  - R3: inside the budget, high picks the lowest latency, medium the least-utilized node,
    low the farthest/highest-capacity node (keeps Edge and Fog free for urgent tasks).
  - R4: if nothing eligible is inside the budget, use the lowest-latency eligible node (fallback).
  - R5: if no node is eligible, reject the task with a reason.

**QoS model**: `total latency = node latency + work_ms x node speed_factor x (1 + 1.5 x utilization^2)`.
Targets: high 80 ms, medium 250 ms, low 600 ms. A task *succeeds* if it was placed; *QoS met* means
its simulated latency is within target. Tasks in a batch run concurrently, so utilization is measured
at peak, before VMs are stopped.

**VMs**: every placed task gets a simulated VM record (`vm_id`, host node, CPU/RAM, status, create
and stop steps). Creating reserves CPU/RAM on the host; stopping releases it.

**Security**: login with a placeholder token (only a SHA-256 hash is stored, compared in constant
time). Every task record carries a tenant ID. Normal users can only read their own tenant's records;
the `admin` role can read all. Each access attempt (allowed or denied) is written to an audit log.

## 5. Experiments and results

`python main.py --experiments` records setup, expected outcome, actual outcome and evidence for:
**E1** policy comparison, **E2** overload (reject or reassign), **E3** unauthorized tenant access,
**E4** before/after changing Edge latency and capacity.

Outputs in `results/`: `results_table.csv`, `experiments.json`, per-experiment decision tables,
`exp1_robustness_20_seeds.csv`, `vm_records_example.csv`, and `chart1`..`chart4` PNGs.

## 6. Assumptions and limitations
- The QoS model is a simplified formula, not a measured network or CPU model.
- Tasks in a batch run at the same time; there is no arrival process or task completion queue.
- The security layer is a teaching demo (placeholder tokens, in-memory store, no encryption).
- Numbers shown in the report come from seed 9; the 20-seed check in E1 shows how results vary.
- `evidence/*.png` are rendered from captured console output; take real screenshots of your own
  live run if your instructor wants them.
