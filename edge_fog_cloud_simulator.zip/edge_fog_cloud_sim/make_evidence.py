"""Captures console output of the demo, experiments and tests into evidence/ as
.txt logs plus PNG renderings of the terminal text (used as report screenshots)."""
import os
import subprocess
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = "evidence"
JOBS = {
    "01_demo_run": [sys.executable, "main.py", "--demo"],
    "02_experiments_run": [sys.executable, "main.py", "--experiments"],
    "04_security_experiment": [sys.executable, "-c",
        "import pandas as pd; from simulator.experiments import exp3_unauthorized_access as f;"
        "e=f(); pd.set_option('display.width',200);"
        "print('E3 checks'); print(pd.DataFrame(e['evidence']['steps']).to_string(index=False));"
        "print(); print('Audit log'); print(pd.DataFrame(e['evidence']['audit_log']).to_string(index=False))"],
    "03_unit_tests": [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-t", ".", "-v"],
}


def render(text, path, fontsize=7.2, wrap=150):
    lines = []
    for ln in text.splitlines():
        while len(ln) > wrap:
            lines.append(ln[:wrap])
            ln = "    " + ln[wrap:]
        lines.append(ln)
    h = max(2.0, 0.145 * len(lines) + 0.5)
    fig = plt.figure(figsize=(13, h), facecolor="#1e1e1e")
    fig.text(0.01, 0.99, "\n".join(lines), family="monospace", fontsize=fontsize,
             color="#d4d4d4", va="top", ha="left", linespacing=1.25)
    fig.savefig(path, dpi=140, facecolor="#1e1e1e")
    plt.close(fig)


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for name, cmd in JOBS.items():
        r = subprocess.run(cmd, capture_output=True, text=True)
        text = f"$ {' '.join(['python'] + cmd[1:])}\n\n{r.stdout}{r.stderr}"
        with open(os.path.join(OUT, name + ".txt"), "w") as f:
            f.write(text)
        render(text, os.path.join(OUT, name + ".png"))
        print("captured", name)
