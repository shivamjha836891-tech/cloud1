"""Placement policies.

Each policy has the signature  policy(task, nodes) -> (node | None, placement, reason)
where placement is "preferred", "fallback" or "none".
"""

# Capacity-aware policy parameters
UTIL_CAP = 0.85  # R1: never push a node above 85% utilization
LATENCY_BUDGET_MS = {"high": 30.0, "medium": 100.0, "low": float("inf")}  # R2


def lowest_latency_first(task, nodes):
    """Baseline: always try the lowest-latency node first, then the next lowest.

    Only checks that the task physically fits (up to 100% utilization); it does not
    consider sensitivity or how loaded the node already is.
    """
    for node in sorted(nodes, key=lambda n: n.latency_ms):
        if node.fits(task.cpu, task.mem):
            return node, "preferred", "lowest-latency node with free capacity"
    return None, "none", "no node has enough free CPU/memory"


def capacity_aware(task, nodes):
    """Rule-based, latency- and capacity-aware placement.

    R1 Eligibility: a node is eligible only if the task fits AND the node stays at
       or below UTIL_CAP (85%) utilization after placement.
    R2 Latency budget by sensitivity: high <= 30 ms, medium <= 100 ms, low = any.
    R3 Choice inside the budget:
         high   -> lowest latency (Edge, then Fog)
         medium -> least-utilized node after placement (balances load)
         low    -> highest-latency / highest-capacity node (Cloud first),
                   keeping Edge/Fog free for urgent work
    R4 Fallback: if no eligible node is inside the budget, use the lowest-latency
       eligible node anyway (marked "fallback"; QoS may then be violated).
    R5 Reject: if no node is eligible at all, the task fails with a reason.
    """
    eligible = [n for n in nodes if n.fits(task.cpu, task.mem, UTIL_CAP)]
    budget = LATENCY_BUDGET_MS[task.sensitivity]
    in_budget = [n for n in eligible if n.latency_ms <= budget]

    if in_budget:
        if task.sensitivity == "high":
            node = min(in_budget, key=lambda n: n.latency_ms)
            why = "high sensitivity: lowest-latency eligible node within 30 ms"
        elif task.sensitivity == "medium":
            node = min(in_budget, key=lambda n: (n.utilization_if(task.cpu, task.mem),
                                                 n.latency_ms))
            why = "medium sensitivity: least-utilized eligible node within 100 ms"
        else:
            node = max(in_budget, key=lambda n: n.latency_ms)
            why = "low sensitivity: highest-capacity (farthest) eligible node"
        return node, "preferred", why

    if eligible:
        node = min(eligible, key=lambda n: n.latency_ms)
        return node, "fallback", (f"no eligible node within {budget:g} ms budget; "
                                  "used lowest-latency eligible node")

    return None, "none", f"rejected: no node can host it below {UTIL_CAP:.0%} utilization"


POLICIES = {
    "lowest_latency_first": lowest_latency_first,
    "capacity_aware": capacity_aware,
}
