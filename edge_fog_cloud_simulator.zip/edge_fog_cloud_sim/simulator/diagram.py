"""Draws the architecture diagram (docs/architecture.png) with matplotlib."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch


def _box(ax, x, y, w, h, text, fc, ec="#1b2a41", fs=9.5, bold_first=True):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.5",
                                fc=fc, ec=ec, lw=1.4))
    lines = text.split("\n")
    n = len(lines)
    for i, line in enumerate(lines):
        yy = y + h / 2 + (n - 1) * 1.7 - i * 3.4
        ax.text(x + w / 2, yy, line, ha="center", va="center", fontsize=fs,
                fontweight="bold" if (i == 0 and bold_first) else "normal", color="#1b2a41")


def _arrow(ax, p1, p2, label=None, lx=0, ly=1.6, rad=0.0):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=14, lw=1.5,
                                 color="#33415c", connectionstyle=f"arc3,rad={rad}"))
    if label:
        ax.text((p1[0] + p2[0]) / 2 + lx, (p1[1] + p2[1]) / 2 + ly, label, ha="center",
                fontsize=8.2, color="#33415c", style="italic")


def draw(path):
    fig, ax = plt.subplots(figsize=(16, 9))
    ax.set_xlim(0, 160)
    ax.set_ylim(0, 92)
    ax.axis("off")
    ax.text(80, 88, "Edge / Fog / Cloud Task-Placement Simulator: Architecture",
            ha="center", fontsize=16, fontweight="bold", color="#1b2a41")

    base, store, gen = "#e8eef7", "#f3e9f7", "#eaf4ea"
    _box(ax, 2, 58, 21, 18, "Users / Tenants\nalice (T1)  bob (T2)\ncarol (T3)  ops (admin)", base)
    _box(ax, 30, 58, 26, 18, "Login + Access Control\ndemo token check\nrole + tenant ID", store)
    _box(ax, 63, 58, 27, 18, "Workload / Task Queue\n12+ tasks: CPU, memory,\nlatency sensitivity", gen)
    _box(ax, 97, 40, 32, 36, "Placement Engine\nPolicy A: lowest-latency-first\nPolicy B: capacity-aware\n"
         "R1 85% utilization cap\nR2 latency budget by sensitivity\nR3 pick node  R4 fallback\nR5 reject with reason",
         "#fff3d6", fs=9.2)
    _box(ax, 30, 36, 26, 14, "Protected Task Store\ntenant-scoped records\n+ audit log", store)
    _box(ax, 97, 12, 32, 18, "VM Manager (simulated)\nvm_id, host, CPU/RAM, status\ncreate / stop", base)
    _box(ax, 63, 12, 27, 18, "QoS Engine\nsimulated latency, utilization\nsuccess / failed, QoS met", gen)
    _box(ax, 30, 12, 26, 18, "Results + Reports\ntables (CSV/JSON)\ncharts (PNG)", "#fde8e8")

    ax.add_patch(FancyBboxPatch((134, 16), 24, 66, boxstyle="round,pad=0.4,rounding_size=1.5",
                                fc="#f7f7f7", ec="#8d99ae", lw=1.2, ls="--"))
    ax.text(146, 79, "Simulated nodes", ha="center", fontsize=10, fontweight="bold", color="#33415c")
    _box(ax, 136, 56, 20, 16, "EDGE\n4 vCPU, 8 GB\n5 ms", "#bfe6e3")
    _box(ax, 136, 37, 20, 16, "FOG\n16 vCPU, 32 GB\n25 ms", "#fbe3b0")
    _box(ax, 136, 18, 20, 16, "CLOUD\n64 vCPU, 256 GB\n80 ms", "#c9d9f2")

    _arrow(ax, (23, 67), (30, 67), "submit")
    _arrow(ax, (56, 67), (63, 67), "authorized")
    _arrow(ax, (90, 67), (97, 67), "tasks")
    _arrow(ax, (43, 58), (43, 50), "own-tenant\nrecords only", lx=-9, ly=0)
    _arrow(ax, (129, 70), (136, 64), None)
    _arrow(ax, (129, 58), (136, 45), None)
    _arrow(ax, (129, 46), (136, 27), None)
    _arrow(ax, (113, 40), (113, 30), "create VM", lx=8, ly=0)
    _arrow(ax, (129, 21), (136, 24), None)
    ax.text(133, 8.5, "reserve CPU/RAM on host", ha="center", fontsize=8.2, color="#33415c", style="italic")
    _arrow(ax, (97, 21), (90, 21), "utilization", ly=1.6)
    _arrow(ax, (63, 21), (56, 21), "metrics", ly=1.6)
    ax.text(80, 3, "Everything runs locally in Python. No real cloud, VMs or hypervisor. "
            "Demo tokens are placeholders (no real passwords).", ha="center", fontsize=9.5,
            color="#555", style="italic")
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
