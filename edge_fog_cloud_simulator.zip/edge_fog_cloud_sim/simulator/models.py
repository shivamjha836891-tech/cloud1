"""Data models for the Edge/Fog/Cloud simulator."""
from dataclasses import dataclass, asdict
from typing import Optional

SENSITIVITY_LEVELS = ("low", "medium", "high")
EPS = 1e-9


@dataclass
class Node:
    """A simulated compute node (Edge, Fog or Cloud)."""
    name: str
    tier: str                 # "edge" | "fog" | "cloud"
    cpu_total: float          # vCPU cores
    mem_total: float          # GB
    latency_ms: float         # network round-trip time to this node
    speed_factor: float = 1.0  # processing-time multiplier (lower = faster CPU)
    cpu_used: float = 0.0     # includes background load
    mem_used: float = 0.0

    @property
    def cpu_free(self) -> float:
        return self.cpu_total - self.cpu_used

    @property
    def mem_free(self) -> float:
        return self.mem_total - self.mem_used

    @property
    def utilization(self) -> float:
        """Current utilization = the more loaded of CPU and memory (0..1)."""
        return max(self.cpu_used / self.cpu_total, self.mem_used / self.mem_total)

    def utilization_if(self, cpu: float, mem: float) -> float:
        return max((self.cpu_used + cpu) / self.cpu_total,
                   (self.mem_used + mem) / self.mem_total)

    def fits(self, cpu: float, mem: float, cap: float = 1.0) -> bool:
        """True if the request fits and utilization stays <= cap after placement."""
        return (cpu <= self.cpu_free + EPS and mem <= self.mem_free + EPS
                and self.utilization_if(cpu, mem) <= cap + EPS)

    def allocate(self, cpu: float, mem: float) -> None:
        if not self.fits(cpu, mem):
            raise ValueError(f"{self.name}: not enough free resources")
        self.cpu_used += cpu
        self.mem_used += mem

    def release(self, cpu: float, mem: float) -> None:
        self.cpu_used = max(0.0, self.cpu_used - cpu)
        self.mem_used = max(0.0, self.mem_used - mem)


@dataclass
class Task:
    """A computing task submitted by a tenant."""
    task_id: str
    tenant_id: str
    cpu: float                # vCPU cores required
    mem: float                # GB required
    sensitivity: str          # latency sensitivity: low | medium | high
    work_ms: float            # base processing time on a speed_factor=1.0 node
    payload: str = ""         # synthetic "protected" content (no real data)

    def __post_init__(self):
        if self.sensitivity not in SENSITIVITY_LEVELS:
            raise ValueError(f"sensitivity must be one of {SENSITIVITY_LEVELS}")


@dataclass
class VM:
    """Simulated virtual machine record (no hypervisor involved)."""
    vm_id: str
    task_id: str
    host: str                 # node name
    cpu: float
    ram: float
    status: str = "running"   # running | stopped
    created_step: int = 0
    stopped_step: Optional[int] = None


@dataclass
class Decision:
    """Placement decision and QoS outcome for one task."""
    task_id: str
    tenant_id: str
    sensitivity: str
    cpu: float
    mem: float
    policy: str
    outcome: str = "FAILED"          # SUCCESS | FAILED
    placement: str = "none"          # preferred | fallback | none
    node: Optional[str] = None
    tier: Optional[str] = None
    vm_id: Optional[str] = None
    reason: str = ""
    net_latency_ms: Optional[float] = None
    processing_ms: Optional[float] = None
    total_latency_ms: Optional[float] = None
    target_ms: Optional[float] = None
    qos_met: Optional[bool] = None

    def as_dict(self) -> dict:
        return asdict(self)
