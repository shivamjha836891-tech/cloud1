"""Workload generation: seeded random tasks, or tasks loaded from CSV."""
import csv
import random

from .models import Task

# (cpu choices, mem GB choices, work_ms range) per latency sensitivity
PROFILES = {
    "high": ([1, 2], [1, 2, 3], (20, 60)),
    "medium": ([2, 3, 4], [2, 4, 6], (60, 150)),
    "low": ([4, 6, 8], [8, 12, 16], (150, 400)),
}
FIELDS = ["task_id", "tenant_id", "cpu", "mem", "sensitivity", "work_ms", "payload"]


def generate_workload(n=12, seed=9, tenants=("T1", "T2", "T3"),
                      weights=(("high", 0.45), ("medium", 0.30), ("low", 0.25))):
    """Create n reproducible tasks. Same seed -> same workload."""
    rng = random.Random(seed)
    levels = [w[0] for w in weights]
    probs = [w[1] for w in weights]
    tasks = []
    for i in range(1, n + 1):
        sens = rng.choices(levels, probs)[0]
        cpus, mems, (lo, hi) = PROFILES[sens]
        tenant = rng.choice(tenants)
        tid = f"task-{i:03d}"
        tasks.append(Task(tid, tenant, rng.choice(cpus), rng.choice(mems), sens,
                          rng.randint(lo, hi), payload=f"synthetic-protected-{tenant}-{tid}"))
    return tasks


def save_workload_csv(tasks, path):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for t in tasks:
            w.writerow({k: getattr(t, k) for k in FIELDS})


def load_workload_csv(path):
    tasks = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            tasks.append(Task(r["task_id"], r["tenant_id"], float(r["cpu"]), float(r["mem"]),
                              r["sensitivity"], float(r["work_ms"]), r.get("payload", "")))
    return tasks
