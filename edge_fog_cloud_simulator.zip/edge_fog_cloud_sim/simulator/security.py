"""Basic security: demo login, roles and tenant isolation.

IMPORTANT: the "tokens" below are obvious placeholders for a classroom demo.
No real passwords or sensitive data are stored anywhere in this project.
Only SHA-256 hashes of the demo tokens are kept, and tokens are compared in
constant time.
"""
import hashlib
import hmac
from dataclasses import dataclass


def _h(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# username -> tenant, role, hash of a placeholder demo token (e.g. "demo-alice")
DEMO_USERS = {
    "alice": {"tenant": "T1", "role": "user", "token_sha256": _h("demo-alice")},
    "bob": {"tenant": "T2", "role": "user", "token_sha256": _h("demo-bob")},
    "carol": {"tenant": "T3", "role": "user", "token_sha256": _h("demo-carol")},
    "ops": {"tenant": "OPS", "role": "admin", "token_sha256": _h("demo-ops")},
}


class AuthError(Exception):
    """Login failed."""


class AccessDenied(Exception):
    """Authenticated user is not allowed to see this record."""


@dataclass(frozen=True)
class Session:
    username: str
    tenant: str
    role: str


def login(username: str, token: str) -> Session:
    user = DEMO_USERS.get(username)
    supplied = _h(token or "")
    stored = user["token_sha256"] if user else _h("no-such-user")
    ok = hmac.compare_digest(supplied, stored)  # constant-time compare
    if user is None or not ok:
        raise AuthError("invalid username or token")
    return Session(username, user["tenant"], user["role"])


class TaskStore:
    """Holds protected task records and enforces tenant isolation."""

    def __init__(self):
        self._records = {}     # task_id -> record dict
        self.audit_log = []    # every access attempt, allowed or denied

    def add(self, task) -> None:
        self._records[task.task_id] = {
            "task_id": task.task_id, "tenant_id": task.tenant_id, "cpu": task.cpu,
            "mem": task.mem, "sensitivity": task.sensitivity, "payload": task.payload,
        }

    def _log(self, session, action, target, result):
        self.audit_log.append({"user": session.username, "tenant": session.tenant,
                               "role": session.role, "action": action,
                               "target": target, "result": result})

    def get(self, session: Session, task_id: str) -> dict:
        rec = self._records.get(task_id)
        if rec is None:
            self._log(session, "read", task_id, "NOT_FOUND")
            raise KeyError(f"task {task_id} not found")
        if session.role != "admin" and rec["tenant_id"] != session.tenant:
            self._log(session, "read", task_id, "DENIED")
            raise AccessDenied(f"{session.username} ({session.tenant}) may not read "
                               f"{task_id} owned by another tenant")
        self._log(session, "read", task_id, "ALLOWED")
        return dict(rec)

    def list_for(self, session: Session) -> list:
        if session.role == "admin":
            visible = list(self._records.values())
        else:
            visible = [r for r in self._records.values()
                       if r["tenant_id"] == session.tenant]
        self._log(session, "list", "*", f"ALLOWED ({len(visible)} records)")
        return [dict(r) for r in visible]
