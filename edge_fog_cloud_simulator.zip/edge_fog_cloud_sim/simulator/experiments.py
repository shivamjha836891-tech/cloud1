"""Required experiments. Each returns a dict with:
id, title, setup, expected, actual, evidence, expectation_met."""
import copy
import json
import os

import pandas as pd

from .engine import Simulator, default_nodes
from .models import Task
from .policies import POLICIES
from .security import AccessDenied, AuthError, login
from .workload import generate_workload, save_workload_csv

DEFAULT_SEED = 9
DECISION_COLS = ["task_id", "tenant_id", "sensitivity", "cpu", "mem", "policy", "node",
                 "placement", "outcome", "total_latency_ms", "target_ms", "qos_met", "reason"]


def _rows(result):
    return [{k: d.as_dict()[k] for k in DECISION_COLS} for d in result.decisions]


def _run(policy, tasks, nodes=None, release=True):
    return Simulator(nodes, policy).run_batch(copy.deepcopy(tasks), release=release)


# --------------------------------------------------------------------------- E1
def exp1_policy_comparison(seed=DEFAULT_SEED):
    tasks = generate_workload(12, seed)
    runs = {p: _run(p, tasks) for p in POLICIES}
    ll, ca = runs["lowest_latency_first"].summary, runs["capacity_aware"].summary

    # robustness check: same comparison over 20 different seeds
    rob = []
    for s in range(1, 21):
        wl = generate_workload(12, s)
        a = _run("lowest_latency_first", wl).summary
        b = _run("capacity_aware", wl).summary
        rob.append({"seed": s, "ll_succeeded": a["succeeded"], "ca_succeeded": b["succeeded"],
                    "ll_qos_met": a["qos_met"], "ca_qos_met": b["qos_met"],
                    "ll_avg_latency": a["avg_latency_ms"], "ca_avg_latency": b["avg_latency_ms"],
                    "ll_util_edge": a["util_edge-1"], "ca_util_edge": b["util_edge-1"]})
    rdf = pd.DataFrame(rob)
    better = int((rdf.ca_qos_met > rdf.ll_qos_met).sum())
    equal = int((rdf.ca_qos_met == rdf.ll_qos_met).sum())
    worse = int((rdf.ca_qos_met < rdf.ll_qos_met).sum())
    lost = int((rdf.ca_succeeded < rdf.ll_succeeded).sum())

    met = ca["qos_met"] >= ll["qos_met"] and ca["util_edge-1"] < ll["util_edge-1"]
    actual = (
        f"Lowest-latency-first: {ll['succeeded']}/{ll['total_tasks']} placed, {ll['qos_met']} met QoS, "
        f"avg latency {ll['avg_latency_ms']} ms, Edge utilization {ll['util_edge-1']:.0%}. "
        f"Capacity-aware: {ca['succeeded']}/{ca['total_tasks']} placed, {ca['qos_met']} met QoS, "
        f"avg latency {ca['avg_latency_ms']} ms, Edge utilization {ca['util_edge-1']:.0%}. "
        f"Over 20 seeds capacity-aware met QoS for more tasks in {better} seeds, equal in {equal}, "
        f"fewer in {worse}; it placed fewer tasks (rejected some) in {lost} seeds."
    )
    return {
        "id": "E1", "title": "Policy comparison on the same workload",
        "setup": (f"Workload: 12 tasks, seed {seed}, 3 tenants, mixed sensitivities. Nodes: default "
                  "Edge/Fog/Cloud with background load. Both policies run on identical copies of the "
                  "nodes and tasks."),
        "expected": ("Lowest-latency-first packs the Edge node to 100% and causes congestion, so more "
                     "tasks miss their QoS target. Capacity-aware keeps nodes at or below 85%, spreading "
                     "load and meeting QoS for at least as many tasks, at the price of possible rejections."),
        "actual": actual,
        "evidence": {"summary": [ll, ca], "decisions": {p: _rows(r) for p, r in runs.items()},
                     "nodes": {p: r.nodes for p, r in runs.items()}, "robustness": rob},
        "expectation_met": bool(met),
        "_runs": runs, "_tasks": tasks,
    }


# --------------------------------------------------------------------------- E2
def exp2_overload():
    tasks = []
    for i in range(1, 15):
        t = "T1" if i % 2 else "T2"
        tasks.append(Task(f"burst-{i:02d}", t, 2, 3, "high", 40, f"synthetic-{t}-{i}"))
    tasks.insert(7, Task("burst-huge", "T1", 80, 32, "high", 100, "synthetic-oversized"))
    r = _run("capacity_aware", tasks)
    s = r.summary
    ok = [d for d in r.decisions if d.outcome == "SUCCESS"]
    on = {n: sum(1 for d in ok if d.node == n) for n in ("edge-1", "fog-1", "cloud-1")}
    failed = [d.task_id for d in r.decisions if d.outcome == "FAILED"]
    met = (len(failed) == 1 and failed[0] == "burst-huge" and on["edge-1"] >= 1
           and s["fallback_placements"] >= 1)
    actual = (f"{s['succeeded']} of {s['total_tasks']} tasks placed: Edge {on['edge-1']}, "
              f"Fog {on['fog-1']}, Cloud {on['cloud-1']}. {s['fallback_placements']} high-sensitivity "
              f"tasks were reassigned (fallback) to a node outside the 30 ms budget, and "
              f"{s['qos_violated']} of the placed tasks missed their QoS target. Rejected: "
              f"{', '.join(failed) or 'none'} (needs 80 vCPU, more than any node owns).")
    return {
        "id": "E2", "title": "Overload: reject or reassign",
        "setup": ("Burst of 14 high-sensitivity tasks (2 vCPU, 3 GB each) plus one oversized task "
                  "(80 vCPU) submitted to the default nodes with the capacity-aware policy."),
        "expected": ("Edge accepts what fits under the 85% cap, Fog takes the next tasks, and the rest are "
                     "reassigned to Cloud as fallback (QoS likely violated). The oversized task cannot "
                     "fit on any node and must be rejected with a reason."),
        "actual": actual,
        "evidence": {"summary": [s], "decisions": _rows(r), "nodes": r.nodes},
        "expectation_met": bool(met), "_runs": {"capacity_aware": r},
    }


# --------------------------------------------------------------------------- E3
def exp3_unauthorized_access(base_run=None):
    tasks = base_run or generate_workload(12, DEFAULT_SEED)
    sim = Simulator(policy="capacity_aware")
    sim.run_batch(copy.deepcopy(tasks))
    t1 = next(t for t in tasks if t.tenant_id == "T1")
    t2 = next(t for t in tasks if t.tenant_id == "T2")
    steps = []

    def attempt(label, fn, expect):
        try:
            res = fn()
            outcome = "ALLOWED"
        except AuthError:
            outcome = "LOGIN_REJECTED"
        except AccessDenied:
            outcome = "DENIED"
        steps.append({"step": label, "expected": expect, "actual": outcome,
                      "pass": outcome == expect})

    attempt("alice logs in with a wrong token", lambda: login("alice", "wrong-token"), "LOGIN_REJECTED")
    alice, bob, ops = login("alice", "demo-alice"), login("bob", "demo-bob"), login("ops", "demo-ops")
    attempt(f"alice (T1) reads her own {t1.task_id}", lambda: sim.store.get(alice, t1.task_id), "ALLOWED")
    attempt(f"alice (T1) reads {t2.task_id} owned by T2", lambda: sim.store.get(alice, t2.task_id), "DENIED")
    attempt(f"bob (T2) reads {t2.task_id}", lambda: sim.store.get(bob, t2.task_id), "ALLOWED")
    attempt(f"bob (T2) reads {t1.task_id} owned by T1", lambda: sim.store.get(bob, t1.task_id), "DENIED")
    attempt(f"ops (admin) reads {t2.task_id}", lambda: sim.store.get(ops, t2.task_id), "ALLOWED")
    listed = sim.store.list_for(alice)
    leak = [r["task_id"] for r in listed if r["tenant_id"] != "T1"]
    steps.append({"step": "alice lists all tasks (should only see T1)",
                  "expected": "0 foreign records", "actual": f"{len(leak)} foreign records",
                  "pass": not leak})
    met = all(s["pass"] for s in steps)
    denied = sum(1 for a in sim.store.audit_log if a["result"] == "DENIED")
    actual = (f"{sum(s['pass'] for s in steps)}/{len(steps)} checks behaved as expected. The audit log "
              f"recorded {denied} DENIED cross-tenant reads; alice's task listing contained "
              f"{len(listed)} records, all from tenant T1.")
    return {
        "id": "E3", "title": "Unauthorized tenant access attempt",
        "setup": ("Demo users alice (T1), bob (T2) and ops (admin) with placeholder tokens. After a normal "
                  "run, alice tries to read a T2 task, bob tries to read a T1 task, and alice tries a "
                  "wrong token."),
        "expected": ("Own-tenant reads succeed. Cross-tenant reads by normal users are denied and logged. "
                     "A task listing only shows the caller's tenant. A wrong token is rejected. The admin "
                     "role may read any tenant's records."),
        "actual": actual,
        "evidence": {"steps": steps, "audit_log": sim.store.audit_log},
        "expectation_met": bool(met),
    }


# --------------------------------------------------------------------------- E4
def exp4_before_after(seed=DEFAULT_SEED):
    tasks = generate_workload(12, seed)

    def variant(mutator):
        nodes = default_nodes()
        mutator(nodes)
        return _run("capacity_aware", tasks, nodes)

    def edge(nodes):
        return next(n for n in nodes if n.tier == "edge")

    def slow_edge(nodes):
        edge(nodes).latency_ms = 60

    def big_edge(nodes):
        e = edge(nodes)
        e.cpu_total, e.mem_total = 16, 32

    scenarios = {"baseline": variant(lambda n: None),
                 "edge_latency_5_to_60ms": variant(slow_edge),
                 "edge_capacity_4_to_16_cpu": variant(big_edge)}
    sm = {k: v.summary for k, v in scenarios.items()}
    b, a, c = sm["baseline"], sm["edge_latency_5_to_60ms"], sm["edge_capacity_4_to_16_cpu"]
    met = (a["placed_edge-1"] < b["placed_edge-1"] and c["placed_edge-1"] > b["placed_edge-1"]
           and c["avg_latency_ms"] <= b["avg_latency_ms"])
    actual = (
        f"Baseline: {b['succeeded']}/12 placed, Edge hosts {b['placed_edge-1']}, avg latency "
        f"{b['avg_latency_ms']} ms, {b['qos_met']} QoS met. Edge latency 5->60 ms: {a['succeeded']}/12 placed, "
        f"Edge hosts {a['placed_edge-1']}, avg latency {a['avg_latency_ms']} ms, {a['qos_met']} QoS met. "
        f"Edge capacity 4->16 vCPU: {c['succeeded']}/12 placed, Edge hosts {c['placed_edge-1']}, avg latency "
        f"{c['avg_latency_ms']} ms, {c['qos_met']} QoS met.")
    if a["failed"]:
        actual += (f" With the slow Edge, {a['failed']} task was rejected: its work moved to Fog and Cloud, "
                   "which then hit the 85% utilization cap.")
    if a["avg_latency_ms"] <= b["avg_latency_ms"]:
        actual += (" Note: average latency did not rise when Edge got slower, because the rules moved "
                   "tasks off the small, congested Edge node (congestion costs more than the extra "
                   "network delay in this model).")
    return {
        "id": "E4", "title": "Before and after changing a node's latency or capacity",
        "setup": (f"Capacity-aware policy, same 12-task workload (seed {seed}). Three runs: baseline; Edge "
                  "latency raised from 5 ms to 60 ms; Edge capacity raised from 4 vCPU/8 GB to 16 vCPU/32 GB."),
        "expected": ("A slower Edge (60 ms) falls outside the 30 ms budget, so high-sensitivity tasks move "
                     "to Fog and Edge hosts fewer tasks. A bigger Edge hosts more tasks and lowers average "
                     "latency."),
        "actual": actual,
        "evidence": {"summary": [dict(scenario=k, **v) for k, v in sm.items()],
                     "decisions": {k: _rows(v) for k, v in scenarios.items()},
                     "nodes": {k: v.nodes for k, v in scenarios.items()}},
        "expectation_met": bool(met), "_runs": scenarios,
    }


# --------------------------------------------------------------------------- run all
def run_all(results_dir="results"):
    os.makedirs(results_dir, exist_ok=True)
    e1 = exp1_policy_comparison()
    e2 = exp2_overload()
    e3 = exp3_unauthorized_access(e1["_tasks"])
    e4 = exp4_before_after()
    exps = [e1, e2, e3, e4]
    save_workload_csv(e1["_tasks"], os.path.join(results_dir, "workload_seed9.csv"))

    # CSV evidence
    pd.DataFrame(e1["evidence"]["decisions"]["lowest_latency_first"]).to_csv(
        os.path.join(results_dir, "exp1_decisions_lowest_latency_first.csv"), index=False)
    pd.DataFrame(e1["evidence"]["decisions"]["capacity_aware"]).to_csv(
        os.path.join(results_dir, "exp1_decisions_capacity_aware.csv"), index=False)
    pd.DataFrame(e1["evidence"]["robustness"]).to_csv(
        os.path.join(results_dir, "exp1_robustness_20_seeds.csv"), index=False)
    pd.DataFrame(e2["evidence"]["decisions"]).to_csv(
        os.path.join(results_dir, "exp2_overload_decisions.csv"), index=False)
    pd.DataFrame(e3["evidence"]["audit_log"]).to_csv(
        os.path.join(results_dir, "exp3_security_audit_log.csv"), index=False)
    pd.DataFrame(e3["evidence"]["steps"]).to_csv(
        os.path.join(results_dir, "exp3_security_checks.csv"), index=False)
    for name, rows in e4["evidence"]["decisions"].items():
        pd.DataFrame(rows).to_csv(os.path.join(results_dir, f"exp4_decisions_{name}.csv"), index=False)
    # VM records from one run (shows create + stop)
    vm_sim = Simulator(policy="capacity_aware")
    vm_sim.run_batch(copy.deepcopy(e1["_tasks"]))
    pd.DataFrame(vm_sim.vms.records()).to_csv(os.path.join(results_dir, "vm_records_example.csv"), index=False)

    # combined results table
    table = []
    for p, r in e1["_runs"].items():
        table.append({"experiment": "E1", "scenario": "same workload", **r.summary})
    table.append({"experiment": "E2", "scenario": "overload burst", **e2["evidence"]["summary"][0]})
    for k, r in e4["_runs"].items():
        table.append({"experiment": "E4", "scenario": k, **r.summary})
    pd.DataFrame(table).to_csv(os.path.join(results_dir, "results_table.csv"), index=False)

    clean = [{k: v for k, v in e.items() if not k.startswith("_")} for e in exps]
    with open(os.path.join(results_dir, "experiments.json"), "w") as f:
        json.dump(clean, f, indent=2, default=str)
    return exps
