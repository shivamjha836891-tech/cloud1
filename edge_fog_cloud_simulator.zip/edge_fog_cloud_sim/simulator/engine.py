"""Simulation engine: places tasks, creates VMs, computes QoS."""
import copy
from dataclasses import dataclass, field

from .models import Node, Task, Decision
from .policies import POLICIES
from .security import TaskStore
from .vm_manager import VMManager

# --- QoS model (documented assumptions) --------------------------------------
CONGESTION_K = 1.5                                   # slowdown at 100% utilization = 1 + K
QOS_TARGET_MS = {"high": 80.0, "medium": 250.0, "low": 600.0}  # end-to-end latency targets


def default_nodes():
    """One Edge, one Fog and one Cloud node with some background load."""
    return [
        Node("edge-1", "edge", cpu_total=4, mem_total=8, latency_ms=5,
             speed_factor=1.2, cpu_used=1, mem_used=2),
        Node("fog-1", "fog", cpu_total=16, mem_total=32, latency_ms=25,
             speed_factor=1.0, cpu_used=6, mem_used=12),
        Node("cloud-1", "cloud", cpu_total=64, mem_total=256, latency_ms=80,
             speed_factor=0.6, cpu_used=16, mem_used=64),
    ]


@dataclass
class RunResult:
    policy: str
    decisions: list
    nodes: list                  # per-node snapshot at peak (before VMs are stopped)
    summary: dict = field(default_factory=dict)


class Simulator:
    def __init__(self, nodes=None, policy="capacity_aware"):
        if policy not in POLICIES:
            raise ValueError(f"unknown policy {policy!r}; choose from {list(POLICIES)}")
        self.policy_name = policy
        self.policy = POLICIES[policy]
        self.nodes = {n.name: n for n in copy.deepcopy(nodes or default_nodes())}
        self.vms = VMManager(self.nodes)
        self.store = TaskStore()
        self.decisions = []
        self._work_ms = {}               # task_id -> base processing time

    # -- placement -------------------------------------------------------------
    def submit(self, task: Task) -> Decision:
        self.store.add(task)
        d = Decision(task.task_id, task.tenant_id, task.sensitivity,
                     task.cpu, task.mem, self.policy_name)
        node, placement, reason = self.policy(task, list(self.nodes.values()))
        d.reason = reason
        if node is None:
            d.outcome, d.placement = "FAILED", "none"
        else:
            vm = self.vms.create(node.name, task.cpu, task.mem, task.task_id)
            d.outcome, d.placement = "SUCCESS", placement
            d.node, d.tier, d.vm_id = node.name, node.tier, vm.vm_id
        self._work_ms[task.task_id] = task.work_ms
        self.decisions.append(d)
        return d

    # -- QoS -------------------------------------------------------------------
    def finalize(self):
        """Compute simulated latency/QoS using each node's current utilization."""
        for d in self.decisions:
            if d.outcome != "SUCCESS" or d.total_latency_ms is not None:
                continue
            node = self.nodes[d.node]
            slowdown = 1 + CONGESTION_K * node.utilization ** 2
            d.net_latency_ms = node.latency_ms
            d.processing_ms = round(self._work_ms[d.task_id] * node.speed_factor * slowdown, 1)
            d.total_latency_ms = round(d.net_latency_ms + d.processing_ms, 1)
            d.target_ms = QOS_TARGET_MS[d.sensitivity]
            d.qos_met = d.total_latency_ms <= d.target_ms

    def snapshot(self):
        return [{"node": n.name, "tier": n.tier, "cpu_used": round(n.cpu_used, 2),
                 "cpu_total": n.cpu_total, "mem_used": round(n.mem_used, 2),
                 "mem_total": n.mem_total, "latency_ms": n.latency_ms,
                 "utilization": round(n.utilization, 3)} for n in self.nodes.values()]

    def run_batch(self, tasks, release=True) -> RunResult:
        """Submit all tasks at once (they run concurrently), then compute QoS."""
        for t in tasks:
            self.submit(t)
        self.finalize()
        nodes = self.snapshot()           # peak utilization, all VMs still running
        if release:
            self.vms.stop_all()
        return RunResult(self.policy_name, self.decisions, nodes, self.summary(nodes))

    def summary(self, nodes=None) -> dict:
        nodes = nodes or self.snapshot()
        ok = [d for d in self.decisions if d.outcome == "SUCCESS"]
        lat = [d.total_latency_ms for d in ok]
        return {
            "policy": self.policy_name,
            "total_tasks": len(self.decisions),
            "succeeded": len(ok),
            "failed": len(self.decisions) - len(ok),
            "qos_met": sum(1 for d in ok if d.qos_met),
            "qos_violated": sum(1 for d in ok if not d.qos_met),
            "fallback_placements": sum(1 for d in ok if d.placement == "fallback"),
            "avg_latency_ms": round(sum(lat) / len(lat), 1) if lat else None,
            "max_latency_ms": max(lat) if lat else None,
            **{f"placed_{n['node']}": sum(1 for d in ok if d.node == n["node"])
               for n in nodes},
            **{f"util_{n['node']}": n["utilization"] for n in nodes},
        }
