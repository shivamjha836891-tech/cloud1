"""matplotlib charts for the experiment results (saved as PNG)."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

NODES = ["edge-1", "fog-1", "cloud-1"]
COL = {"lowest_latency_first": "#d1495b", "capacity_aware": "#00798c",
       "ok": "#2e8b57", "bad": "#d1495b", "fail": "#555555"}
LABEL = {"lowest_latency_first": "Lowest-latency-first", "capacity_aware": "Capacity-aware"}
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})


def chart_policy_comparison(e1, path):
    runs = e1["_runs"]
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2))
    x, w = np.arange(len(NODES)), 0.38
    for i, (p, r) in enumerate(runs.items()):
        placed = [r.summary[f"placed_{n}"] for n in NODES]
        util = [r.summary[f"util_{n}"] * 100 for n in NODES]
        ax[0].bar(x + (i - .5) * w, placed, w, label=LABEL[p], color=COL[p])
        ax[1].bar(x + (i - .5) * w, util, w, label=LABEL[p], color=COL[p])
    ax[0].set(title="Tasks placed per node", ylabel="tasks", xticks=x, xticklabels=NODES)
    ax[1].axhline(85, ls="--", color="black", lw=1)
    ax[1].text(2.45, 86, "85% cap", ha="right", fontsize=9)
    ax[1].set(title="Peak utilization per node", ylabel="% (max of CPU, memory)",
              xticks=x, xticklabels=NODES, ylim=(0, 112))
    ax[0].legend(frameon=False)
    # QoS outcome stacked bars
    names = list(runs)
    met = [runs[p].summary["qos_met"] for p in names]
    vio = [runs[p].summary["qos_violated"] for p in names]
    fail = [runs[p].summary["failed"] for p in names]
    xs = np.arange(len(names))
    ax[2].bar(xs, met, color=COL["ok"], label="QoS met")
    ax[2].bar(xs, vio, bottom=met, color=COL["bad"], label="QoS violated")
    ax[2].bar(xs, fail, bottom=np.add(met, vio), color=COL["fail"], label="Rejected")
    ax[2].set(title="Task outcomes (12 tasks)", ylabel="tasks", xticks=xs,
              xticklabels=[LABEL[p] for p in names], ylim=(0, 15.5))
    ax[2].legend(frameon=False, loc="upper center", ncol=3, fontsize=8.5,
                 handlelength=1.2, columnspacing=1.0)
    fig.suptitle("Experiment 1: same workload, two placement policies", fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def chart_latency_per_task(e1, path):
    fig, ax = plt.subplots(figsize=(12, 4.2))
    ids = [d.task_id[-3:] for d in e1["_runs"]["capacity_aware"].decisions]
    x, w = np.arange(len(ids)), 0.38
    for i, (p, r) in enumerate(e1["_runs"].items()):
        vals = [d.total_latency_ms or 0 for d in r.decisions]
        ax.bar(x + (i - .5) * w, vals, w, label=LABEL[p], color=COL[p])
    targets = [d.target_ms for d in e1["_runs"]["capacity_aware"].decisions]
    ax.scatter(x, targets, marker="_", s=900, color="black", zorder=3, label="QoS target")
    ax.set(xticks=x, xticklabels=ids, xlabel="task number", ylabel="simulated latency (ms)",
           title="Experiment 1: simulated end-to-end latency per task vs QoS target")
    ax.legend(frameon=False, ncol=3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def chart_overload(e2, path):
    r = e2["_runs"]["capacity_aware"]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    pref = [sum(1 for d in r.decisions if d.node == n and d.placement == "preferred") for n in NODES]
    fall = [sum(1 for d in r.decisions if d.node == n and d.placement == "fallback") for n in NODES]
    rej = sum(1 for d in r.decisions if d.outcome == "FAILED")
    labels = NODES + ["rejected"]
    ax[0].bar(labels, pref + [0], color="#00798c", label="preferred placement")
    ax[0].bar(labels, fall + [0], bottom=pref + [0], color="#edae49", label="fallback (reassigned)")
    ax[0].bar(labels, [0, 0, 0, rej], color="#555555", label="rejected")
    ax[0].set(title="Where the 15 burst tasks went", ylabel="tasks")
    ax[0].legend(frameon=False)
    util = [n["utilization"] * 100 for n in r.nodes]
    ax[1].bar(NODES, util, color="#00798c")
    ax[1].axhline(85, ls="--", color="black", lw=1)
    ax[1].set(title="Peak utilization after the burst", ylabel="%", ylim=(0, 100))
    for i, u in enumerate(util):
        ax[1].text(i, u + 1.5, f"{u:.0f}%", ha="center")
    fig.suptitle("Experiment 2: overload scenario", fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def chart_before_after(e4, path):
    runs = e4["_runs"]
    names = list(runs)
    short = ["baseline", "Edge latency\n5 -> 60 ms", "Edge capacity\n4 -> 16 vCPU"]
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2))
    x, w = np.arange(len(names)), 0.26
    for i, n in enumerate(NODES):
        ax[0].bar(x + (i - 1) * w, [runs[k].summary[f"placed_{n}"] for k in names], w, label=n)
    ax[0].set(title="Tasks placed per node", ylabel="tasks", xticks=x, xticklabels=short)
    ax[0].legend(frameon=False)
    avg = [runs[k].summary["avg_latency_ms"] for k in names]
    ax[1].bar(x, avg, color="#00798c")
    for i, v in enumerate(avg):
        ax[1].text(i, v + 4, f"{v:.0f}", ha="center")
    ax[1].set(title="Average simulated latency", ylabel="ms", xticks=x, xticklabels=short,
              ylim=(0, max(avg) * 1.2))
    met = [runs[k].summary["qos_met"] for k in names]
    ax[2].bar(x, met, color=COL["ok"])
    for i, v in enumerate(met):
        ax[2].text(i, v + .15, f"{v}/12", ha="center")
    ax[2].set(title="Tasks meeting QoS target", ylabel="tasks", xticks=x, xticklabels=short, ylim=(0, 13.5))
    fig.suptitle("Experiment 4: before and after changing Edge latency / capacity", fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def make_all(exps, results_dir):
    e = {x["id"]: x for x in exps}
    chart_policy_comparison(e["E1"], os.path.join(results_dir, "chart1_policy_comparison.png"))
    chart_latency_per_task(e["E1"], os.path.join(results_dir, "chart2_latency_per_task.png"))
    chart_overload(e["E2"], os.path.join(results_dir, "chart3_overload.png"))
    chart_before_after(e["E4"], os.path.join(results_dir, "chart4_before_after.png"))
