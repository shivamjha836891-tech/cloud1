"""Simulated VM records. No hypervisor: a VM is just a record that reserves
CPU/RAM on its host node until it is stopped."""
from .models import VM


class VMManager:
    def __init__(self, nodes: dict):
        self.nodes = nodes            # name -> Node (shared with the Simulator)
        self.vms = {}                 # vm_id -> VM
        self._counter = 0
        self.step = 0                 # simulated clock (one tick per operation)

    def create(self, host: str, cpu: float, ram: float, task_id: str = "manual") -> VM:
        node = self.nodes[host]
        node.allocate(cpu, ram)       # raises ValueError if it does not fit
        self._counter += 1
        self.step += 1
        vm = VM(vm_id=f"vm-{self._counter:03d}", task_id=task_id, host=host,
                cpu=cpu, ram=ram, status="running", created_step=self.step)
        self.vms[vm.vm_id] = vm
        return vm

    def stop(self, vm_id: str) -> VM:
        vm = self.vms.get(vm_id)
        if vm is None:
            raise KeyError(f"unknown VM {vm_id}")
        if vm.status == "stopped":
            raise ValueError(f"{vm_id} is already stopped")
        self.nodes[vm.host].release(vm.cpu, vm.ram)
        self.step += 1
        vm.status = "stopped"
        vm.stopped_step = self.step
        return vm

    def stop_all(self) -> int:
        running = [v for v in self.vms.values() if v.status == "running"]
        for vm in running:
            self.stop(vm.vm_id)
        return len(running)

    def records(self) -> list:
        return [vars(v).copy() for v in self.vms.values()]
